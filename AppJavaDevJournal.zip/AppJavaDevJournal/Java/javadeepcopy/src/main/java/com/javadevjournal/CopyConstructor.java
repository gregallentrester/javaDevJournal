package com.javadevjournal;

public class CopyConstructor {
}
