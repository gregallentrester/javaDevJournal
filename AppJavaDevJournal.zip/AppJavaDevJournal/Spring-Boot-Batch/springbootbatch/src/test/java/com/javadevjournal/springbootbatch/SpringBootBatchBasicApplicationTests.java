package com.javadevjournal.springbootbatch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * @Author - Kunwar Vikas
 */
@SpringBootTest
class SpringBootBatchBasicApplicationTests {

	@Test
	void contextLoads() {
	}

}
