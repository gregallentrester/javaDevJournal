package com.javadevjournal.profilemanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProfilemanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
