package com.javadevjournal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSessionAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringSessionAppApplication.class, args);
    }
}
