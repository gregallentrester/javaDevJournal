package com.javadevjournal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringOrderAnnotationApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringOrderAnnotationApplication.class, args);
    }
}
