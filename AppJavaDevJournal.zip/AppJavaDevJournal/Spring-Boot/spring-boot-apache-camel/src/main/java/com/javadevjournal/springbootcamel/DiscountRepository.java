package com.javadevjournal.springbootcamel;

import org.springframework.data.repository.CrudRepository;

public interface DiscountRepository extends CrudRepository<Discount, Integer> {

}
