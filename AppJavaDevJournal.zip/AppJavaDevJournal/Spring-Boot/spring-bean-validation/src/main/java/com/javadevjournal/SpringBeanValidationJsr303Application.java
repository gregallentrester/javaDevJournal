package com.javadevjournal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBeanValidationJsr303Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBeanValidationJsr303Application.class, args);
	}

}

