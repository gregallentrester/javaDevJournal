package com.javadevjournal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootLog4J2ExampleApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootLog4J2ExampleApplication.class, args);
    }

}

