package com.javadevjournal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavadevjournalThymeleafExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavadevjournalThymeleafExampleApplication.class, args);
	}
}
