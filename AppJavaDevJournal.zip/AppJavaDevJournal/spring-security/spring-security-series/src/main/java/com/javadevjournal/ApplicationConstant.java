package com.javadevjournal;

public class ApplicationConstant {

  public static final String REDIRECT="redirect:";
}
